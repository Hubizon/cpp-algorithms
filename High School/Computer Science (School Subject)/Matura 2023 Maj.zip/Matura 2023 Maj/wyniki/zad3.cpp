#include <iostream>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

bool isRosMal(const vector<int>& V) {
    for (int k = 1; k < V.size() - 2; k++) {
        bool is_ok = true;
        for (int i = 0; i < k; i++)
            if (V[i] >= V[i + 1])
                is_ok = false;
        for (int i = k + 1; i < V.size() - 1; i++)
            if (V[i] <= V[i + 1])
                is_ok = false;
        if (is_ok)
            return true;
    }
    return false;
}

int main()
{
    ofstream out("wyniki3.txt");

    ifstream in("pi.txt"); // pi_przyklad.txt
    const int FILE_SIZE = 10000; // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   
    vector<int> V(FILE_SIZE);
    for (auto& v : V)
        in >> v;

    // zad 3.1,
    int res1 = 0;
    vector<int> V2(100);
    for (int i = 0; i < V.size() - 1; i++) {
        int x = V[i] * 10 + V[i + 1];
        if (x > 90)
            res1++;
        V2[x]++;
    }

    out << "zad 3.1.: " << res1 << '\n';

    // zad 3.2
    int res2max = 0, res2maxCnt = -1;
    int res2min = 0, res2minCnt = INT32_MAX;
    for (int i = 0; i < V2.size(); i++) {
        if (V2[i] > res2maxCnt) {
            res2max = i;
            res2maxCnt = V2[i];
        }
        if (V2[i] < res2minCnt) {
            res2min = i;
            res2minCnt = V2[i];
        }
    }

    out << "zad 3.2.:\n" << res2min << ' ' << res2minCnt << '\n'
        << res2max << ' ' << res2maxCnt << '\n'; // TODO: zmienic r�cznie leading zeros!!!!!

    // zad 3.3
    int res3 = 0;
    for (int i = 0; i < V.size() - 6; i++) {
        vector<int> V3 = { V[i], V[i + 1], V[i + 2], V[i + 3], V[i + 4], V[i + 5] };
        if (isRosMal(V3))
            res3++;
    }

    out << "zad 3.3.: " << res3 << '\n';

    // zad 3.4
    int res4pos = -1;
    string res4 = "";
    for (int i = 0; i < V.size() - 3; i++) {
        int is_ros = -1, malEnd = V.size() - 1;
        for (int j = i; j < V.size() - 1; j++) {
            if (is_ros == -1) {
                if (V[j] >= V[j + 1]) {
                    is_ros = j;
                }
            }
            else {
                if (V[j] <= V[j + 1]) {
                    malEnd = j;
                    break;
                }
            }
        }

        if (is_ros > i && malEnd > is_ros + 1) {
            int s = malEnd - i + 1;
            if (s > res4.size()) {
                res4pos = i + 1;
                res4 = "";
                for (int j = i; j < i + s; j++)
                    res4 += to_string(V[j]);
            }
        }
    }

    out << "zad 3.4.:\n" << res4pos << '\n' << res4 << '\n';
}
