#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int blockCount(string bin) {
    int b = 1;
    for (int i = 1; i < bin.size(); i++)
        if (bin[i] != bin[i - 1])
            b++;
    return b;
}

int binToDec(string bin) {
    int res = 0, x = 1;
    for (int i = bin.size() - 1; i >= 0; i--) {
        if (bin[i] == '1')
            res += x;
        x *= 2;
    }
    return res;
}

string decToBin(int x) {
    string res = "";
    while (x) {
        res += ('0' + (x % 2));
        x /= 2;
    }
    return string(res.rbegin(), res.rend());
}

int main()
{
    ifstream in("bin.txt");
    ofstream out1("wyniki2.txt");
    ofstream out2("wyniki2_5.txt");

    int res1 = 0, res2 = 0;
    string res2bin = "";
    while (in) {
        string bin;
        getline(in, bin);
        if (bin == "")
            break;

        // zad 2.2
        if (blockCount(bin) <= 2)
            res1++;

        // zad 2.3
        if (binToDec(bin) > res2) {
            res2 = binToDec(bin);
            res2bin = bin;
        }

        // zad 2.5
        int p = binToDec(bin);
        int p2 = p / 2;
        int pxorp2 = p ^ p2;
        string res5 = decToBin(pxorp2);
        out2 << res5 << '\n';
    }

    out1 << "zad 2.2: " << res1 << '\n';
    out1 << "zad 2.3: " << res2bin << '\n';

    in.close();
    out1.close();
    out2.close();
}
