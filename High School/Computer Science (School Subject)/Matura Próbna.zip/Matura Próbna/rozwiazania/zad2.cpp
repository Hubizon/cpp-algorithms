﻿#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const string INFILE = "krosno.txt";
const string OUTFILE = "wyniki2.txt"; 
const int N = 100;

bool czy_k_rosnaca(vector<int>& A, int n, int k) {
	for (int i = 0; i < n - k; i++) 
		if (A[i] >= A[i + k])
			return false;

	return true;
}

int main()
{
	ifstream in(INFILE);
	ofstream out(OUTFILE);

	vector<int> A(N);
	for (auto& a : A)
		in >> a;

	for (int k = 1; k < 100; k++)
		if (czy_k_rosnaca(A, N, k))
			out << k << ' ';

	in.close();
	out.close();
}

