﻿#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const string INFILE("zawody2.txt");
const int N = 5000;

bool isPrime(int x) {
	for (int i = 2; i < x; i++) {
		if (x % i == 0)
			return false;
	}
	return true;
}

int main()
{
	ifstream in(INFILE);

	vector<pair<int, int>> V(N);
	for (auto& [a, b] : V) {
		in >> a >> b;
	}

	int cnt4a = 0;
	for (auto& [a, b] : V) {
		if (isPrime(b))
			cnt4a++;
	}

	cout << "Zadanie 5.4.:\na) " << cnt4a;

	vector<int> res4b;
	for (auto& [a, b] : V) {
		if (isPrime(b))
			res4b.push_back(a);
	}

	cout << "\nb) ";
	for (int i = 0; i < 10; i++)
		cout << res4b[i] << ' ';

	in.close();
}

