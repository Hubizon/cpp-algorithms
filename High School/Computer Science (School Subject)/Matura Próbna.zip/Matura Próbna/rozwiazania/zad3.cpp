﻿#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int cnt = 0;

int Kop(vector<vector<int>>& A, int n, int m, int i, int j) {
	if (i > n || j > m)
		return 0;
	int k1 = Kop(A, n, m, i + 1, j);
	int k2 = Kop(A, n, m, i, j + 1);
	if (k1 > k2)
		return A[i][j] + k1;
	return A[i][j] + k2;
}

int KopIter(vector<vector<int>>& A, int n, int m, int i, int j) {
	i--, j--;
	vector<vector<int>> DP(n, vector<int>(m));
	for (int it = n - 1; it >= 0; it--) {
		for (int jt = m - 1; jt >= 0; jt--) {
			if (it + 1 < n)
				DP[it][jt] = DP[it + 1][jt];
			if (jt + 1 < m && DP[it][jt] < DP[it][jt + 1])
				DP[it][jt] = DP[it][jt + 1];
			DP[it][jt] += A[it][jt];
		}
	}

	return DP[i][j];
}

int main()
{
	vector<vector<int>> A = { { 4, 2, 1, 10, 5 },
		{ 0, 4, 22, 2, 8 }, { 40, 1, 1, 1, 1 } };
	int n = 3, m = 5;

	int i = 2, j = 4;
	cout << Kop(A, n - 1, m - 1, i - 1, j - 1) << endl;
	cout << KopIter(A, n, m, i, j);
}
