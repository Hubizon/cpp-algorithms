﻿#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <set>

using namespace std;

const string INFILE = "konta.txt";
const string OUTFILE = "wyniki4.txt";
const int N = 6;

int main()
{
	ifstream in(INFILE);
	ofstream out(OUTFILE);

	map<string, set<string>> M, RM;
	set<string> cats;
	for (int i = 0; i < N; i++) {
		string a, b;
		in >> a >> b;
		M[a].insert(b);
		RM[b].insert(a);

		cats.insert(a);
		cats.insert(b);
	}

	out << "Zadanie 4.1.: " << cats.size() << '\n';

	out << "Zadanie 4.2.:\n";
	for (auto& cat : cats) 
		if (RM[cat].size() == 0)
			out << cat << '\n';
	
	int res3 = 0;
	for (auto& [key, val] : M) 
		for (auto v : val) 
			if (M[v].count(key))
				res3++;
		
	out << "Zadanie 4.3.: " << res3 / 2 << '\n';

	int res4cnt = 0;
	string res4 = *cats.begin();
	for (auto& [key, val] : M) {
		if (val.size() > res4cnt) {
			res4cnt = val.size();
			res4 = key;
		}
	}	
	out << "Zadanie 4.4.: " << res4 << '\n';

	map<string, int> toRes5;
	for (auto& cat : cats) {
		toRes5[cat] += RM[cat].size();
		if (RM[cat].size() == 0) {
			// cat jest falszywy
			for (auto& v : M[cat])
				toRes5[v]--;
		}
	}

	int res5cnt = 0;
	string res5 = *cats.begin();
	for (auto& [key, val] : toRes5) {
		if (res5cnt < val) {
			res5cnt = val;
			res5 = key;
		}
	}	
	out << "Zadanie 4.5.: " << res5 << '\n';

	in.close();
	out.close();
}

