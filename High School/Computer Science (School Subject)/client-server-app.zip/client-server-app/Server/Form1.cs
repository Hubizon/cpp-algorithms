﻿using System;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Windows.Forms;

namespace Server {
	public partial class Form1 : Form {
		public Form1() {
			InitializeComponent();
			
			Server.MessageSentEvent += delegate(string message) {
				LbMessageAddItem(new ColoredText(message, Color.CadetBlue));
			};
			Server.SystemMessageSentEvent += delegate(string message) {
				LbMessageAddItem(new ColoredText(message, Color.IndianRed));
			};
			Server.ClientJoinedEvent += delegate(Client client) {
				lbClients.Items.Add(client);
				ExpandLbClients();
			};
			Server.ClientLeftEvent += delegate(Client client) {
				lbClients.Items.Remove(client);
				ExpandLbClients();
			};
		}

		private void LbMessageAddItem(ColoredText text) {
			lbMessage.Items.Add(text);
			var requiredSize = (int) Math.Ceiling(lbMessage.CreateGraphics().MeasureString(text.Text, lbMessage.Font).Width);
			lbMessage.HorizontalExtent = Math.Max(requiredSize, lbMessage.HorizontalExtent);
			
			var visibleItems = lbMessage.ClientSize.Height / lbMessage.ItemHeight;
			if(lbMessage.Items.Count - visibleItems - 1 == lbMessage.TopIndex)
				lbMessage.TopIndex = Math.Max(lbMessage.Items.Count - visibleItems + 1, 0);
		}

		private void ExpandLbClients() {
			var maxWidth = lbClients.Items.OfType<Client>().Select(
				client => (int) Math.Ceiling(
					lbClients.CreateGraphics().MeasureString(client.ToString(), lbMessage.Font).Width)
				).Prepend(0).Max();

			lbClients.HorizontalExtent = maxWidth;
		}

		private void bStart_Click(object sender, EventArgs e) {
			Server.Start(tbHostAddress.Text, Convert.ToUInt16(nUDPort.Text));

			bStart.Enabled = false;
			bStop.Enabled = true;
			bSend.Enabled = true;
			tbHostAddress.Enabled = false;
			nUDPort.Enabled = false;
			tbMessage.Enabled = true;
		}

		private void bStop_Click(object sender, EventArgs e) {
			Server.Stop();
			
			bStart.Enabled = true;
			bStop.Enabled = false;
			bSend.Enabled = false;
			tbHostAddress.Enabled = true;
			nUDPort.Enabled = true;
			tbMessage.Enabled = false;
		}

		private void bSend_Click(object sender, EventArgs e) {
			var message = tbMessage.Text;
			tbMessage.Text = "";

			Server.Broadcast(message, false, "Server");
		}

		private void tbHostAddress_TextChanged(object sender, EventArgs e) {
			ValidateServerParameters();
		}
		
		private void ValidateServerParameters() {
			try {
				IPAddress.Parse(tbHostAddress.Text);
			}
			catch (FormatException) {
				bStart.Enabled = false;
				return;
			}

			bStart.Enabled = true;
		}

		private void lbMessage_DrawItem(object sender, DrawItemEventArgs args) {
			if (args.Index < 0)
				return;
			
			if (lbMessage.Items[args.Index] is ColoredText item) {
				if (args.Index < 0)
					return;
				
				//Change selection color
				if ((args.State & DrawItemState.Selected) == DrawItemState.Selected)
					args = new DrawItemEventArgs(
						args.Graphics, 
						args.Font, 
						args.Bounds, 
						args.Index,
						args.State ^ DrawItemState.Selected,
						args.ForeColor, 
						Color.White);
				
				args.DrawBackground();
				args.Graphics.DrawString(
					item.Text, 
					args.Font, 
					new SolidBrush(item.Color), 
					args.Bounds);
			}
		}

		private void lbClients_DrawItem(object sender, DrawItemEventArgs args) {
			if (args.Index < 0)
				return;
			
			if (lbClients.Items[args.Index] is Client item) {
				//Change selection color
				if ((args.State & DrawItemState.Selected) == DrawItemState.Selected)
					args = new DrawItemEventArgs(
						args.Graphics, 
						args.Font,
						args.Bounds, 
						args.Index,
						args.State ^ DrawItemState.Selected,
						Color.Black, 
						Color.White);
				
				args.DrawBackground();
				args.Graphics.DrawString(
					item.ToString(), 
					args.Font, 
					new SolidBrush(args.ForeColor), 
					args.Bounds);
			}
		}
	}
}
