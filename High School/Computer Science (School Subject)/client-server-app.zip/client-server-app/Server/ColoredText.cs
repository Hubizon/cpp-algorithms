﻿using System.Drawing;

namespace Server {
	public class ColoredText {
		public readonly string Text;
		public readonly Color Color;
		
		public ColoredText(string text, Color color) {
			Text = text;
			Color = color;
		}
	}
}