﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Server {
	public static class Server {
		private static readonly System.Windows.Forms.Timer ClientPresenceVerifier = new System.Windows.Forms.Timer();
		private static readonly List<Client> Clients = new List<Client>();
		private static readonly SynchronizationContext MainThread;
		private static Thread _connectionListenerThread;
		private static TcpListener _clientListener;
		private static string _address;
		private static ushort _port;

		private static readonly Dictionary<string, string> PendingPrivateConnections = new Dictionary<string, string>();
		private static readonly Dictionary<string, string> PrivateConnections = new Dictionary<string, string>();

		public delegate void MessageSentEventHandler(string message);
		public static event MessageSentEventHandler MessageSentEvent;
		public delegate void SystemMessageSentEventHandler(string message);
		public static event SystemMessageSentEventHandler SystemMessageSentEvent;
		public delegate void ClientJoinedEventHandler(Client client);
		public static event ClientJoinedEventHandler ClientJoinedEvent;
		public delegate void ClientLeftEventHandler(Client client);
		public static event ClientLeftEventHandler ClientLeftEvent;

		static Server() {
			MainThread = SynchronizationContext.Current;
		}
		
		private static void ConnectionListener() {
			while (true) {
				TcpClient clientConnection;
				try { 
					clientConnection = _clientListener.AcceptTcpClient();
				}
				catch (SocketException) { 
					break;
				}

				var client = new Client(ref clientConnection);
				
				Broadcast($"{client.Name} joined the server.", true);
				MainThread.Send(func => ClientJoinedEvent?.Invoke(client), null);
				Clients.Add(client);
			}
		}

		public static void Start(string address, ushort port) {
			_address = address;
			_port = port;

			try {
				_clientListener = new TcpListener(IPAddress.Parse(_address), _port);
			}
			catch (FormatException) {
				MainThread.Send(func => SystemMessageSentEvent?.Invoke("Invalid IP address!"), null);
				return;
			}

			_clientListener.Start();
			_connectionListenerThread = new Thread(ConnectionListener);
			_connectionListenerThread.Start();

			ClientPresenceVerifier.Tick += VerifyClientPresence;
			ClientPresenceVerifier.Interval = 1000;
			ClientPresenceVerifier.Start();

			MainThread.Send(func => SystemMessageSentEvent?.Invoke("Started server..."), null);
		}

		public static void Stop() {
			ClientPresenceVerifier.Stop();

			while(Clients.Count > 0)
				Delete(Clients[0], false);
			
			_clientListener.Stop();
			MainThread.Send(func => SystemMessageSentEvent?.Invoke("Stopped server..."), null);
		}

		public static void Broadcast(string message, bool isSystemMessage, string sender = null) {
			var fullMessage = ((sender == null) ? "" : sender + ": ") + message;
			
			foreach (var client in Clients.Where(client => client.Name != sender))
				client.SendMessage(fullMessage);

			if(isSystemMessage)
				MainThread.Send(func => SystemMessageSentEvent?.Invoke(fullMessage), null);
			else
				MainThread.Send(func => MessageSentEvent?.Invoke(fullMessage), null);
		}

		public static void HandlePrivateMessage(string message, string sender) {
			if (PrivateConnections.ContainsKey(sender)) {
				if (message == "@END") {
					MainThread.Send(func => SystemMessageSentEvent?.Invoke(
						$"{sender} disconnected from {PrivateConnections[sender]}."), null);
					SendPrivateMessage("@END", PrivateConnections[sender]);
					PrivateConnections.Remove(PrivateConnections[sender]);
					PrivateConnections.Remove(sender);
				}
				else {
					SendPrivateMessage(message, PrivateConnections[sender]);
					message = message.Substring(1);
					MainThread.Send(func => SystemMessageSentEvent?.Invoke(
						$"{sender} to {PrivateConnections[sender]}: {message}"), null);
				}
			}
			else if (message == "@END" && PendingPrivateConnections.ContainsKey(sender)) {
				MainThread.Send(func => SystemMessageSentEvent?.Invoke(
					$"{sender} no longer wants to message {PendingPrivateConnections[sender]}."), null);
				SendPrivateMessage($"{sender} no longer wants to message you.", PendingPrivateConnections[sender]);
				PendingPrivateConnections.Remove(sender);
			}
			else if (message.Length > 2 && message.StartsWith("@\"")) {
				var target = message.Split('"', '"')[1];

				if (!Client.UsedNames.Contains(target) || target == sender)
					SendPrivateMessage("@WRONG", sender);
				else {
					if (PendingPrivateConnections.ContainsKey(target) && PendingPrivateConnections[target] == sender) {
						MainThread.Send(func => SystemMessageSentEvent?.Invoke(
							$"{sender} connected with {target}."), null);
						
						PendingPrivateConnections.Remove(target);
						
						PrivateConnections.Add(sender, target);
						PrivateConnections.Add(target, sender);
						
						SendPrivateMessage("@START", sender);
						SendPrivateMessage("@START", target);
					}
					else {
						MainThread.Send(func => SystemMessageSentEvent?.Invoke(
							$"{sender} wants to message {target}."), null);
						
						PendingPrivateConnections.Add(sender, target);
						SendPrivateMessage($"{sender} wants to message you.", target);
					}
				}
			}
			else
				SendPrivateMessage("Invalid message.", sender);
		}

		public static void SendPrivateMessage(string message, string target) {
			foreach (var client in Clients.Where(client => client.Name == target)) {
				client.SendMessage(message);
				return;
			}
		}

		public static void Delete(Client disconnectedClient, bool announceLeaving = true) {
			if (!Clients.Contains(disconnectedClient))
				return;
			
			MainThread.Send(func => ClientLeftEvent?.Invoke(disconnectedClient), null);

			var name = disconnectedClient.Name;
			disconnectedClient.CloseConnection();
			Clients.Remove(disconnectedClient);
			
			if(announceLeaving)
				Broadcast($"{name} left the server.", true);

			if (PrivateConnections.ContainsKey(name)) {
				SendPrivateMessage("@END", PrivateConnections[name]);
				PrivateConnections.Remove(PrivateConnections[name]);
				PrivateConnections.Remove(name);
			}
			else if (PendingPrivateConnections.ContainsKey(name)) {
				SendPrivateMessage($"{name} no longer wants to message you.", PendingPrivateConnections[name]);
				PendingPrivateConnections.Remove(name);
			}
		}

		private static void VerifyClientPresence(object sender, EventArgs e) {
			foreach (var client in Clients.Where(client => !client.IsConnected())) {
				Delete(client);
			}
		}
	}
}