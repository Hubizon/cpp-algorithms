﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Threading;

namespace Server {
	public class Client {
		public static readonly HashSet<string> UsedNames = new HashSet<string>();

		public readonly string Name;
		private readonly DateTime _connectionTimestamp;

		private readonly TcpClient _connection;
		private readonly BinaryReader _reader;
		private readonly BinaryWriter _writer;

		public Client(ref TcpClient connection) {
			_reader = new BinaryReader(connection.GetStream());
			_writer = new BinaryWriter(connection.GetStream());
			_connectionTimestamp = DateTime.Now;
			_connection = connection;
			
			var name = _reader.ReadString();
			name = name.Replace("\n", "").Replace("\r", "");
			if (name.Length > 25)
				name = name.Substring(0, 25);
			
			//Making sure name is not a duplicate
			while (UsedNames.Contains(name))
				name += "-clone";
			UsedNames.Add(name);
			
			Name = name;

			var messageListenerThread = new Thread(MessageListener);
			messageListenerThread.Start();
		}

		private void MessageListener() {
			while (true) {
				try {
					var message = _reader.ReadString();
					message = message.Replace("\n", "").Replace("\r", "");
					
					if (message.Length > 5000) {
						Server.SendPrivateMessage("The message you sent was too long.", Name);
					}
					else if (message.StartsWith("@")) {
						Server.HandlePrivateMessage(message, Name);
					}
					else if (message == "END") {
						break;
					}
					else if(message != string.Empty)
						Server.Broadcast(message, false, Name);
				}
				catch (Exception) {
					break;
				}
			}
			
			UsedNames.Remove(Name);
			Server.Delete(this);
		}

		public void SendMessage(string message) {
			if (!IsConnected()) {
				Server.Delete(this);
				return;
			}

			_writer.Write(message);
			_writer.Flush();
		}

		public bool IsConnected() {
			try {
				_writer.Write(string.Empty);
			}
			catch (Exception) {
				return false;
			}

			return true;
		}

		public void CloseConnection() {
			_connection.Close();
		}
		
		public override string ToString() {
			return $"{Name} [Joined at {_connectionTimestamp:h:mm:ss tt}]";
		}
	}
}