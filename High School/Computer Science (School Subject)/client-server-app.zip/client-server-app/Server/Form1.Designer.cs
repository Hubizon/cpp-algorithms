﻿namespace Server
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.lblAddress = new System.Windows.Forms.Label();
			this.tbHostAddress = new System.Windows.Forms.TextBox();
			this.lblPort = new System.Windows.Forms.Label();
			this.nUDPort = new System.Windows.Forms.NumericUpDown();
			this.lbMessage = new System.Windows.Forms.ListBox();
			this.bStart = new System.Windows.Forms.Button();
			this.bStop = new System.Windows.Forms.Button();
			this.bSend = new System.Windows.Forms.Button();
			this.tbMessage = new System.Windows.Forms.TextBox();
			this.lbClients = new System.Windows.Forms.ListBox();
			((System.ComponentModel.ISupportInitialize)(this.nUDPort)).BeginInit();
			this.SuspendLayout();
			// 
			// lblAddress
			// 
			this.lblAddress.AutoSize = true;
			this.lblAddress.Location = new System.Drawing.Point(33, 37);
			this.lblAddress.Name = "lblAddress";
			this.lblAddress.Size = new System.Drawing.Size(60, 17);
			this.lblAddress.TabIndex = 0;
			this.lblAddress.Text = "Address";
			// 
			// tbHostAddress
			// 
			this.tbHostAddress.Location = new System.Drawing.Point(99, 34);
			this.tbHostAddress.Name = "tbHostAddress";
			this.tbHostAddress.Size = new System.Drawing.Size(254, 22);
			this.tbHostAddress.TabIndex = 3;
			this.tbHostAddress.Text = "127.0.0.1";
			this.tbHostAddress.TextChanged += new System.EventHandler(this.tbHostAddress_TextChanged);
			// 
			// lblPort
			// 
			this.lblPort.AutoSize = true;
			this.lblPort.Location = new System.Drawing.Point(495, 34);
			this.lblPort.Name = "lblPort";
			this.lblPort.Size = new System.Drawing.Size(34, 17);
			this.lblPort.TabIndex = 4;
			this.lblPort.Text = "Port";
			// 
			// nUDPort
			// 
			this.nUDPort.Location = new System.Drawing.Point(535, 32);
			this.nUDPort.Maximum = new decimal(new int[] { 65535, 0, 0, 0 });
			this.nUDPort.Name = "nUDPort";
			this.nUDPort.Size = new System.Drawing.Size(120, 22);
			this.nUDPort.TabIndex = 5;
			this.nUDPort.Value = new decimal(new int[] { 100, 0, 0, 0 });
			// 
			// lbMessage
			// 
			this.lbMessage.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.lbMessage.FormattingEnabled = true;
			this.lbMessage.HorizontalScrollbar = true;
			this.lbMessage.ItemHeight = 16;
			this.lbMessage.Location = new System.Drawing.Point(36, 96);
			this.lbMessage.Name = "lbMessage";
			this.lbMessage.Size = new System.Drawing.Size(293, 260);
			this.lbMessage.TabIndex = 6;
			this.lbMessage.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lbMessage_DrawItem);
			// 
			// bStart
			// 
			this.bStart.Location = new System.Drawing.Point(36, 371);
			this.bStart.Name = "bStart";
			this.bStart.Size = new System.Drawing.Size(100, 28);
			this.bStart.TabIndex = 7;
			this.bStart.Text = "Start";
			this.bStart.UseVisualStyleBackColor = true;
			this.bStart.Click += new System.EventHandler(this.bStart_Click);
			// 
			// bStop
			// 
			this.bStop.Enabled = false;
			this.bStop.Location = new System.Drawing.Point(555, 371);
			this.bStop.Name = "bStop";
			this.bStop.Size = new System.Drawing.Size(100, 28);
			this.bStop.TabIndex = 8;
			this.bStop.Text = "Stop";
			this.bStop.UseVisualStyleBackColor = true;
			this.bStop.Click += new System.EventHandler(this.bStop_Click);
			// 
			// bSend
			// 
			this.bSend.Enabled = false;
			this.bSend.Location = new System.Drawing.Point(300, 574);
			this.bSend.Name = "bSend";
			this.bSend.Size = new System.Drawing.Size(100, 28);
			this.bSend.TabIndex = 10;
			this.bSend.Text = "Send";
			this.bSend.UseVisualStyleBackColor = true;
			this.bSend.Click += new System.EventHandler(this.bSend_Click);
			// 
			// tbMessage
			// 
			this.tbMessage.Enabled = false;
			this.tbMessage.Location = new System.Drawing.Point(36, 405);
			this.tbMessage.Multiline = true;
			this.tbMessage.Name = "tbMessage";
			this.tbMessage.Size = new System.Drawing.Size(619, 132);
			this.tbMessage.TabIndex = 11;
			// 
			// lbClients
			// 
			this.lbClients.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.lbClients.FormattingEnabled = true;
			this.lbClients.HorizontalScrollbar = true;
			this.lbClients.ItemHeight = 16;
			this.lbClients.Location = new System.Drawing.Point(362, 96);
			this.lbClients.Name = "lbClients";
			this.lbClients.Size = new System.Drawing.Size(293, 260);
			this.lbClients.Sorted = true;
			this.lbClients.TabIndex = 14;
			this.lbClients.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lbClients_DrawItem);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(694, 614);
			this.Controls.Add(this.lbClients);
			this.Controls.Add(this.tbMessage);
			this.Controls.Add(this.bSend);
			this.Controls.Add(this.bStop);
			this.Controls.Add(this.bStart);
			this.Controls.Add(this.lbMessage);
			this.Controls.Add(this.nUDPort);
			this.Controls.Add(this.lblPort);
			this.Controls.Add(this.tbHostAddress);
			this.Controls.Add(this.lblAddress);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Location = new System.Drawing.Point(15, 15);
			this.Name = "Form1";
			this.Text = "Server";
			((System.ComponentModel.ISupportInitialize)(this.nUDPort)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		private System.Windows.Forms.ListBox lbClients;

		private System.Windows.Forms.ListBox listBox2;

		#endregion

		private System.Windows.Forms.Label lblAddress;
		private System.Windows.Forms.TextBox tbHostAddress;
		private System.Windows.Forms.Label lblPort;
		private System.Windows.Forms.NumericUpDown nUDPort;
		private System.Windows.Forms.ListBox lbMessage;
		private System.Windows.Forms.Button bStart;
		private System.Windows.Forms.Button bStop;
		private System.Windows.Forms.Button bSend;
		private System.Windows.Forms.TextBox tbMessage;
	}
}