﻿
namespace Client
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.label1 = new System.Windows.Forms.Label();
            this.tbHostAddress = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nUDPort = new System.Windows.Forms.NumericUpDown();
            this.bConnect = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bSend = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNick = new System.Windows.Forms.TextBox();
            this.bDisconnect = new System.Windows.Forms.Button();
            this.tpGlobalChat = new System.Windows.Forms.TabPage();
            this.lbMessages = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpPrivateChat = new System.Windows.Forms.TabPage();
            this.bPvDisconnect = new System.Windows.Forms.Button();
            this.lbPvMessages = new System.Windows.Forms.ListBox();
            this.tbPvChatUser = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.bPvConnect = new System.Windows.Forms.Button();
            this.bSendPv = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nUDPort)).BeginInit();
            this.tpGlobalChat.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpPrivateChat.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Address";
            // 
            // tbHostAddress
            // 
            this.tbHostAddress.Location = new System.Drawing.Point(64, 10);
            this.tbHostAddress.Name = "tbHostAddress";
            this.tbHostAddress.Size = new System.Drawing.Size(221, 20);
            this.tbHostAddress.TabIndex = 1;
            this.tbHostAddress.Text = "127.0.0.1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(375, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Port";
            // 
            // nUDPort
            // 
            this.nUDPort.Location = new System.Drawing.Point(407, 10);
            this.nUDPort.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nUDPort.Name = "nUDPort";
            this.nUDPort.Size = new System.Drawing.Size(81, 20);
            this.nUDPort.TabIndex = 4;
            this.nUDPort.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // bConnect
            // 
            this.bConnect.Enabled = false;
            this.bConnect.Location = new System.Drawing.Point(12, 278);
            this.bConnect.Name = "bConnect";
            this.bConnect.Size = new System.Drawing.Size(75, 23);
            this.bConnect.TabIndex = 5;
            this.bConnect.Text = "Connect";
            this.bConnect.UseVisualStyleBackColor = true;
            this.bConnect.Click += new System.EventHandler(this.BConnect_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 320);
            this.textBox1.MaxLength = 5000;
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(480, 96);
            this.textBox1.TabIndex = 7;
            // 
            // bSend
            // 
            this.bSend.Enabled = false;
            this.bSend.Location = new System.Drawing.Point(12, 426);
            this.bSend.Name = "bSend";
            this.bSend.Size = new System.Drawing.Size(116, 23);
            this.bSend.TabIndex = 8;
            this.bSend.Text = "Send to global chat";
            this.bSend.UseVisualStyleBackColor = true;
            this.bSend.Click += new System.EventHandler(this.BSent_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Nick";
            // 
            // tbNick
            // 
            this.tbNick.Location = new System.Drawing.Point(64, 41);
            this.tbNick.MaxLength = 25;
            this.tbNick.Name = "tbNick";
            this.tbNick.Size = new System.Drawing.Size(221, 20);
            this.tbNick.TabIndex = 10;
            this.tbNick.TextChanged += new System.EventHandler(this.TbNick_TextChanged);
            // 
            // bDisconnect
            // 
            this.bDisconnect.Enabled = false;
            this.bDisconnect.Location = new System.Drawing.Point(417, 278);
            this.bDisconnect.Name = "bDisconnect";
            this.bDisconnect.Size = new System.Drawing.Size(75, 23);
            this.bDisconnect.TabIndex = 11;
            this.bDisconnect.Text = "Disconnect";
            this.bDisconnect.UseVisualStyleBackColor = true;
            this.bDisconnect.Click += new System.EventHandler(this.BDisconnect_Click);
            // 
            // tpGlobalChat
            // 
            this.tpGlobalChat.Controls.Add(this.lbMessages);
            this.tpGlobalChat.Location = new System.Drawing.Point(4, 22);
            this.tpGlobalChat.Name = "tpGlobalChat";
            this.tpGlobalChat.Padding = new System.Windows.Forms.Padding(3);
            this.tpGlobalChat.Size = new System.Drawing.Size(472, 174);
            this.tpGlobalChat.TabIndex = 0;
            this.tpGlobalChat.Text = "Global chat";
            this.tpGlobalChat.UseVisualStyleBackColor = true;
            // 
            // lbMessages
            // 
            this.lbMessages.FormattingEnabled = true;
            this.lbMessages.HorizontalScrollbar = true;
            this.lbMessages.Location = new System.Drawing.Point(0, 0);
            this.lbMessages.Name = "lbMessages";
            this.lbMessages.Size = new System.Drawing.Size(472, 173);
            this.lbMessages.TabIndex = 6;
            this.lbMessages.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.LbMessage_DrawItem);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpGlobalChat);
            this.tabControl1.Controls.Add(this.tpPrivateChat);
            this.tabControl1.Location = new System.Drawing.Point(12, 67);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(480, 200);
            this.tabControl1.TabIndex = 12;
            // 
            // tpPrivateChat
            // 
            this.tpPrivateChat.Controls.Add(this.bPvDisconnect);
            this.tpPrivateChat.Controls.Add(this.lbPvMessages);
            this.tpPrivateChat.Controls.Add(this.tbPvChatUser);
            this.tpPrivateChat.Controls.Add(this.label4);
            this.tpPrivateChat.Controls.Add(this.bPvConnect);
            this.tpPrivateChat.Location = new System.Drawing.Point(4, 22);
            this.tpPrivateChat.Name = "tpPrivateChat";
            this.tpPrivateChat.Size = new System.Drawing.Size(472, 174);
            this.tpPrivateChat.TabIndex = 1;
            this.tpPrivateChat.Text = "Private chat";
            this.tpPrivateChat.UseVisualStyleBackColor = true;
            // 
            // bPvDisconnect
            // 
            this.bPvDisconnect.Enabled = false;
            this.bPvDisconnect.Location = new System.Drawing.Point(391, 9);
            this.bPvDisconnect.Name = "bPvDisconnect";
            this.bPvDisconnect.Size = new System.Drawing.Size(75, 23);
            this.bPvDisconnect.TabIndex = 17;
            this.bPvDisconnect.Text = "Disconnect";
            this.bPvDisconnect.UseVisualStyleBackColor = true;
            this.bPvDisconnect.Click += new System.EventHandler(this.BPvDisconnect_Click);
            // 
            // lbPvMessages
            // 
            this.lbPvMessages.FormattingEnabled = true;
            this.lbPvMessages.HorizontalScrollbar = true;
            this.lbPvMessages.Location = new System.Drawing.Point(0, 37);
            this.lbPvMessages.Name = "lbPvMessages";
            this.lbPvMessages.Size = new System.Drawing.Size(472, 134);
            this.lbPvMessages.TabIndex = 16;
            this.lbPvMessages.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.LbPvMessages_DrawItem);
            // 
            // tbPvChatUser
            // 
            this.tbPvChatUser.Location = new System.Drawing.Point(48, 9);
            this.tbPvChatUser.Name = "tbPvChatUser";
            this.tbPvChatUser.Size = new System.Drawing.Size(221, 20);
            this.tbPvChatUser.TabIndex = 15;
            this.tbPvChatUser.TextChanged += new System.EventHandler(this.TbPvChatUser_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "User";
            // 
            // bPvConnect
            // 
            this.bPvConnect.Enabled = false;
            this.bPvConnect.Location = new System.Drawing.Point(310, 9);
            this.bPvConnect.Name = "bPvConnect";
            this.bPvConnect.Size = new System.Drawing.Size(75, 23);
            this.bPvConnect.TabIndex = 13;
            this.bPvConnect.Text = "Connect";
            this.bPvConnect.UseVisualStyleBackColor = true;
            this.bPvConnect.Click += new System.EventHandler(this.BPvConnect_Click);
            // 
            // bSendPv
            // 
            this.bSendPv.Enabled = false;
            this.bSendPv.Location = new System.Drawing.Point(376, 426);
            this.bSendPv.Name = "bSendPv";
            this.bSendPv.Size = new System.Drawing.Size(116, 23);
            this.bSendPv.TabIndex = 13;
            this.bSendPv.Text = "Send to private chat";
            this.bSendPv.UseVisualStyleBackColor = true;
            this.bSendPv.Click += new System.EventHandler(this.BSendPv_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 461);
            this.Controls.Add(this.bSendPv);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.bDisconnect);
            this.Controls.Add(this.tbNick);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.bSend);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.bConnect);
            this.Controls.Add(this.nUDPort);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbHostAddress);
            this.Controls.Add(this.label1);
            this.MaximumSize = new System.Drawing.Size(520, 500);
            this.MinimumSize = new System.Drawing.Size(520, 500);
            this.Name = "Form1";
            this.Text = "Client";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.nUDPort)).EndInit();
            this.tpGlobalChat.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpPrivateChat.ResumeLayout(false);
            this.tpPrivateChat.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbHostAddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nUDPort;
        private System.Windows.Forms.Button bConnect;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button bSend;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbNick;
        private System.Windows.Forms.Button bDisconnect;
        private System.Windows.Forms.TabPage tpGlobalChat;
        private System.Windows.Forms.ListBox lbMessages;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpPrivateChat;
        private System.Windows.Forms.ListBox lbPvMessages;
        private System.Windows.Forms.TextBox tbPvChatUser;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bPvConnect;
        private System.Windows.Forms.Button bPvDisconnect;
        private System.Windows.Forms.Button bSendPv;
    }
}

