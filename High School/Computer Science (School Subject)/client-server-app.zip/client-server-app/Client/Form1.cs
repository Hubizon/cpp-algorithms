﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace Client
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			lbMessages.DrawMode = DrawMode.OwnerDrawFixed;
			lbPvMessages.DrawMode = DrawMode.OwnerDrawFixed;

			Client.MessageSentEvent += delegate (Client.MsgType msgType, string message, bool isPv)
			{
				DisplayMessage(msgType, message, isPv);
			};

			Client.StartConnectionEvent += delegate (bool isPv)
			{
				if (!isPv)
                {
					bSend.Enabled = true;
					bDisconnect.Enabled = true;
					if (tbPvChatUser.Text.Length > 0)
						bPvConnect.Enabled = true;
				}
				else
                {
					bSendPv.Enabled = true;
				}
			};

			Client.DisconnectEvent += delegate (bool isPv)
			{
				if (!isPv) Disconnect();
				else PvDisconnect();
			};
		}
		

		private void BConnect_Click(object sender, EventArgs e)
        {
			Client.Address = tbHostAddress.Text;
			Client.Port = Convert.ToInt16(nUDPort.Value);
			Client.ConnectThread = new Thread(Client.ConnectThreadProc);
			Client.ConnectThread.Start();
			bConnect.Enabled = false;
			tbHostAddress.Enabled = false;
			nUDPort.Enabled = false;
			tbNick.Enabled = false;
        }

        private void BSent_Click(object sender, EventArgs e)
        {
			var messageSent = textBox1.Text;
			DisplayMessage(Client.MsgType.Me, Client.YouText + ": " + messageSent);
			textBox1.Clear();
			Client.Writer?.Write(messageSent);
		}

		private void BDisconnect_Click(object sender, EventArgs e)
		{
			Client.Writer?.Write(Client.EndText);
			Disconnect(true);
		}

		private void TbNick_TextChanged(object sender, EventArgs e)
		{
			Client.Nick = tbNick.Text;
			if (Client.Nick.Length > 0 && !Client.Nick.Contains("@") && !Client.Nick.Contains("\""))
			{
				bConnect.Enabled = true;
			}
			else
			{
				bConnect.Enabled = false;
			}
		}

		private void LbMessage_DrawItem(object sender, DrawItemEventArgs e)
		{
			if (e.Index == -1) return;
			var selectedItem = lbMessages.Items[e.Index].ToString();
			e.DrawBackground();
			e.Graphics.DrawString(selectedItem, e.Font, Client.PrevBrushes[e.Index], e.Bounds.Left, e.Bounds.Top);
		}


		private void BPvConnect_Click(object sender, EventArgs e)
		{
			if (Client.Writer == null) return;
            Client.Writer?.Write($"@\"{Client.PvUser}\"");
			DisplayMessage(Client.MsgType.Info, "Trying to connect...", true);
			bPvConnect.Enabled = false;
			tbPvChatUser.Enabled = false;
			bPvDisconnect.Enabled = true;
		}

		private void BSendPv_Click(object sender, EventArgs e)
		{
			var messageSent = textBox1.Text;
			DisplayMessage(Client.MsgType.Me, Client.YouText + ": " + messageSent, true);
			textBox1.Clear();
			Client.Writer?.Write('@' + messageSent);
		}

        private void BPvDisconnect_Click(object sender, EventArgs e)
        {
			Client.Writer?.Write("@END");
			PvDisconnect();
		}

        private void TbPvChatUser_TextChanged(object sender, EventArgs e)
        {
			Client.PvUser = tbPvChatUser.Text;
			if (Client.PvUser.Length > 0 && Client.IsConnected && !Client.PvUser.Contains("@") && !Client.Nick.Contains("\""))
			{
				bPvConnect.Enabled = true;
			}
			else
			{
				bPvConnect.Enabled = false;
			}
		}

		private void LbPvMessages_DrawItem(object sender, DrawItemEventArgs e)
		{
			if (e.Index == -1) return;
			var selectedItem = lbPvMessages.Items[e.Index].ToString();
			e.DrawBackground();
			e.Graphics.DrawString(selectedItem, e.Font, Client.PrevBrushesPv[e.Index], e.Bounds.Left, e.Bounds.Top);
		}


		private void Disconnect(bool isInformed = false)
		{
			if (!isInformed)
				DisplayMessage(Client.MsgType.Info, "Disconnected");
			if (Client.ConnectThread != null) Client.ConnectThread.Abort();
			if (Client.MessagesThread != null) Client.MessagesThread.Abort();
			Client.IsConnected = false;
			bSend.Enabled = false;
			bConnect.Enabled = true;
			bDisconnect.Enabled = false;
			tbHostAddress.Enabled = true;
			nUDPort.Enabled = true;
			tbNick.Enabled = true;
			PvDisconnect();
			bPvConnect.Enabled = false;
		}

		private void PvDisconnect()
		{
			if (Client.IsConnectedPv)
				DisplayMessage(Client.MsgType.Info, "Disconnected", true);
			tbPvChatUser.Enabled = true;
			bPvConnect.Enabled = true;
			bPvDisconnect.Enabled = false;
			bSendPv.Enabled = false;
			Client.IsConnectedPv = false;
		}

		private void DisplayMessage(Client.MsgType msgType, string message, bool isPv = false)
        {
			if (!isPv)
			{
				Client.SetColor(msgType, Client.PrevBrushes);
				lbMessages.Items.Add(message);

				var hzSize = (int)lbMessages.CreateGraphics().MeasureString(message, lbMessages.Font).Width;
				lbMessages.HorizontalExtent = Math.Max(lbMessages.HorizontalExtent, hzSize);

				var visibleItems = lbMessages.ClientSize.Height / lbMessages.ItemHeight;
				if (lbMessages.Items.Count - visibleItems - 1 == lbMessages.TopIndex)
					lbMessages.TopIndex = Math.Max(lbMessages.Items.Count - visibleItems + 1, 0);
			}
			else
			{
				Client.SetColor(msgType, Client.PrevBrushesPv);
				lbPvMessages.Items.Add(message);

				var hzSize = (int)lbPvMessages.CreateGraphics().MeasureString(message, lbPvMessages.Font).Width;
				lbPvMessages.HorizontalExtent = Math.Max(lbPvMessages.HorizontalExtent, hzSize);

				var visibleItems = lbPvMessages.ClientSize.Height / lbPvMessages.ItemHeight;
				if (lbPvMessages.Items.Count - visibleItems - 1 == lbPvMessages.TopIndex)
					lbPvMessages.TopIndex = Math.Max(lbPvMessages.Items.Count - visibleItems + 1, 0);
			}
		}

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
			Client.ConnectThread?.Abort();
			Client.MessagesThread?.Abort();
        }
    }
}
