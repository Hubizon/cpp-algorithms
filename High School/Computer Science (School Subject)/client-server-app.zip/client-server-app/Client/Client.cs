﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Threading;

namespace Client
{
    public static class Client
    {
		public const string StartText = "START", EndText = "END", WrongText = "WRONG", YouText = "You";
		public static readonly List<SolidBrush> PrevBrushes = new List<SolidBrush>();
		public static readonly List<SolidBrush> PrevBrushesPv = new List<SolidBrush>();
		public static Thread ConnectThread, MessagesThread;
		public static BinaryWriter Writer;
		public static string Address;
		public static int Port;
		public static string Nick, PvUser;
		public static bool IsConnected = false, IsConnectedPv = false;

		private static readonly SynchronizationContext MainThread;
		public delegate void MessageSentEventHandler(MsgType msgType, string message, bool isPv = false);
		public static event MessageSentEventHandler MessageSentEvent;
		public delegate void StartConnectionEventHandler(bool isPv = false);
		public static event StartConnectionEventHandler StartConnectionEvent;
		public delegate void DisconnectEventHandler(bool isPv = false);
		public static event DisconnectEventHandler DisconnectEvent;

		private static TcpClient _client;
		private static BinaryReader _reader;

		public enum MsgType
		{
			Info,
			Me,
			Global,
			Priv,
		}

		static Client()
        {
			MainThread = SynchronizationContext.Current;	
		}

		public static void ConnectThreadProc()
		{
			try
			{
				_client = new TcpClient(Address, Port);
				var ns = _client.GetStream();
				_reader = new BinaryReader(ns);
				Writer = new BinaryWriter(ns);
				Writer.Write(Nick);
				MainThread.Send(func => MessageSentEvent?.Invoke(MsgType.Info, $"Connected with {Address}:{Port}"), null);
				MainThread.Send(func => StartConnectionEvent?.Invoke(), null);
				MessagesThread = new Thread(MessagesThreadProc);
				MessagesThread.Start();
				IsConnected = true;
			}
			catch (Exception)
			{
				MainThread.Send(func => MessageSentEvent?.Invoke(MsgType.Info, "Couldn't establish a connection"), null);
				MainThread.Send(func => DisconnectEvent?.Invoke(), null);
			}
		}

		public static void MessagesThreadProc()
		{
			try
			{
				string messageReceived;
				while (true)
				{
					messageReceived = _reader?.ReadString();
					if (messageReceived == null || messageReceived == "" || messageReceived == "\0") continue;
					if (!messageReceived.StartsWith("@"))
					{
						MainThread.Send(func => MessageSentEvent?.Invoke(MsgType.Global, messageReceived), null);
					}
					else
					{
						messageReceived = messageReceived.Substring(1);
						if (messageReceived == StartText)
						{
							MainThread.Send(func => MessageSentEvent?.Invoke(MsgType.Info, "Successfully connected", true), null);
							MainThread.Send(func => StartConnectionEvent?.Invoke(true), null);
							IsConnectedPv = true;
						}
						else if (messageReceived == EndText)
						{
							MainThread.Send(func => DisconnectEvent?.Invoke(true), null);
						}
						else if (messageReceived == WrongText)
						{
							MainThread.Send(func => MessageSentEvent?.Invoke(MsgType.Info, $"The user {PvUser} does not exist", true), null);
							MainThread.Send(func => DisconnectEvent?.Invoke(true), null);
						}
						else
						{
							MainThread.Send(func => MessageSentEvent?.Invoke(MsgType.Priv, messageReceived, true), null);
						}
					}
				}
			}
			catch
			{
				_client.Close();
				try { MainThread?.Send(func => DisconnectEvent?.Invoke(), null); }
				catch (System.ComponentModel.InvalidAsynchronousStateException) { }
			}
		}

		public static void SetColor(MsgType msgType, List<SolidBrush> brushes)
		{
			switch (msgType)
			{
				case MsgType.Info:
					brushes.Add(new SolidBrush(Color.IndianRed));
					break;
				case MsgType.Priv:
					brushes.Add(new SolidBrush(Color.DarkCyan));
					break;
				case MsgType.Global:
					brushes.Add(new SolidBrush(Color.CadetBlue));
					break;
				case MsgType.Me:
					brushes.Add(new SolidBrush(Color.Black));
					break;
			}
		}

		
	}
}
