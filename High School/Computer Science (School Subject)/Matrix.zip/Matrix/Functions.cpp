#include "Functions.h"

using namespace std;

bool add(Matrix& A, Matrix& B, Matrix& C)
{
    if (A.getM() != B.getM() || A.getN() != B.getN())
        return false;

    C.create(A.getM(), A.getN());

    for (int i = 0, j; i < A.getM(); i++)
        for (j = 0; j < A.getN(); j++)
            C.set(i, j, A.get(i, j) + B.get(i, j));

    return true;
}

bool skalar(double K, Matrix& A, Matrix& C)
{
    C.create(A.getM(), A.getN());

    for (int i = 0, j; i < A.getM(); i++)
        for (j = 0; j < A.getN(); j++)
            C.set(i, j, K * A.get(i, j));

    return true;
}

bool multi(Matrix& A, Matrix& B, Matrix& C)
{
    if (A.getM() != B.getN())
        return false;

    C.create(A.getM(), B.getN());
    for (int i = 0, j; i < A.getM(); i++)
        for (j = 0; j < B.getN(); j++)
            C.set(i, j, 0);

    for (int i = 0; i < A.getM(); i++)
        for (int z = 0; z < A.getN(); z++)
            for (int j = 0; j < B.getN(); j++)
                C.set(i, j, C.get(i, j) + A.get(i, z) * B.get(z, j));

    return true;
}

bool transponse(Matrix& A, Matrix& C)
{
    C.create(A.getN(), A.getM());

    for (int i = 0; i < A.getN(); i++)
        for (int j = 0; j < A.getM(); j++)
            C.set(i, j, A.get(j, i));

    return true;
}

Matrix operator+ (Matrix& A, Matrix& B) {
    if (A.getM() != B.getM() || A.getN() != B.getN())
        throw "Nie mozna dodac tych macierzy.\n\n";

    Matrix temp(A.getM(), A.getN(), "C");

    for (int i = 0, j; i < A.getM(); i++)
            for (j = 0; j < A.getN(); j++)
                temp.set(i, j, A.get(i, j) + B.get(i, j));

    return temp;
}

Matrix operator* (Matrix& A, double b) {
    Matrix temp(A.getM(), A.getN(), "C");

    for (int i = 0, j; i < A.getM(); i++)
        for (j = 0; j < A.getN(); j++)
            temp.set(i, j, b * A.get(i, j));

    return temp;
}

Matrix operator* (Matrix& A, Matrix& B) {
    if (A.getM() != B.getN())
        throw "Nie mozna pomnozyc tych macierzy.\n\n";

    Matrix temp(A.getM(), B.getN(), "C");

    for (int i = 0, j; i < A.getM(); i++)
        for (j = 0; j < B.getN(); j++)
            temp.set(i, j, 0);

    for (int i = 0; i < A.getM(); i++)
        for (int z = 0; z < A.getN(); z++)
            for (int j = 0; j < B.getN(); j++)
                temp.set(i, j, temp.get(i, j) + A.get(i, z) * B.get(z, j));

    return temp;
}

istream& operator>> (istream& s, Matrix& A) {
    for (int i = 0; i < A.getM(); i++)
        for (int j = 0; j < A.getM(); j++)
            s >> A.getA()[i][j];
    return s;
}

ostream& operator<< (ostream& s, Matrix& A) {
    s << "Macierz " << A.getName() << ":\n";
    for (int i = 0, j; i < A.getM(); i++) {
        for (j = 0; j < A.getN(); j++)
            s << setw(8) << A.get(i, j) << ' ';
        s << '\n';
    }
    s << endl;
    return s;
}
