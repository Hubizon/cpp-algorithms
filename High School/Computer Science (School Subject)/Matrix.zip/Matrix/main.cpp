#include <iostream>
#include "Matrix.cpp"
#include "Functions.cpp"

using namespace std;

int main()
{
    Matrix A(3, 4, "A");
    Matrix B(4, 3, "B");
    A.fill(20);
    B.fill();
    cout << A << B;

    Matrix C;

    try {
        C = A + B;
        C.setName("C - dodawanie (A + B)");
        cout << C;
    }
    catch (const char* s) { cout << s; }

    C = A * 2.5;
    C.setName("C - skalar (2.5 * A)");
    cout << C;

    try {
        C = A * B;
        C.setName("C - mnozenie (A x B)");
        cout << C;
    }
    catch (const char* s) { cout << s; }

    C.setName("C - transpozycja (A T)");
    if (transponse(A, C))
        cout << C;

    Matrix D(4, 4, "D");
    D.fill();
    try { cout << D << "Wyznacznik: " << Matrix::determinant(D) << '\n'; }
    catch (const char* s) { cout << s; }
}
