#include "Matrix.h"

using namespace std;

Matrix::Matrix()
{
    a = new double* [0];
    m = 0; 
    n = 0;
    name = "";
}

Matrix::Matrix(int m_, int n_, string name_)
{
    m = m_;
    n = n_;
    name = name_;
    create(m_, n_);
}

Matrix::Matrix(const Matrix& matrix)
{
    *this = matrix;
}

void Matrix::create(int m_, int n_)
{
    m = m_;
    n = n_;
    a = new double* [m_];
    for (int i = 0; i < m_; i++) {
        a[i] = new double[n_];
        for (int j = 0; j < n_; j++)
            a[i][j] = 0;
    }
}

void Matrix::fill(int l)
{
    for (int i = 0, j; i < m; i++)
        for (j = 0; j < n; j++)
            a[i][j] = rand() % l;
}

void Matrix::show()
{
    cout << "Macierz " << name << ":\n";
    for (int i = 0, j; i < m; i++) {
        for (j = 0; j < n; j++)
            cout << setw(5) << a[i][j] << ' ';
        cout << '\n';
    }
    cout << endl;
}

double Matrix::determinant(Matrix& A)
{
    if (A.getM() != A.getN() || A.getM() < 1)
        throw "Macierz musi byc kwadratowa do wykonania tego dzialania.\n";
    int* colAvailable = new int[A.getN()];
    for (int i = 0; i < A.getN(); i++)
        colAvailable[i] = i;
    return Matrix::det(A.getN(), 0, colAvailable, A.getA());
}

double Matrix::det(int n, int startingRow, int* colAvailable, double** a)
{
    if (n == 1)
        return a[startingRow][colAvailable[0]];

    int* newColums = new int[n - 1];
    double s = 0;
    int p = 1;
    for (int i = 0; i < n; i++) {
        int r = 0;
        for (int j = 0; j < n - 1; j++) {
            if (r == i) r++;
            newColums[j] = colAvailable[r++];
        }
        s += p * a[startingRow][colAvailable[i]] * det(n - 1, startingRow + 1, newColums, a);
        p *= -1;
    }

    delete[] newColums;
    return s;
}

Matrix::~Matrix() {
    for (int i = 0; i < m; i++)
        delete[] a[i];
    delete[] a;
}

Matrix& Matrix::operator=(const Matrix& matrix_)
{
    m = matrix_.m;
    n = matrix_.n;
    name = matrix_.name;
    a = new double* [m];
    for (int i = 0; i < m; i++) {
        a[i] = new double[n];
        for (int j = 0; j < n; j++)
            a[i][j] = matrix_.a[i][j];
    }
    return *this;
}