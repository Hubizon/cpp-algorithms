#pragma once
#include <iostream>
#include <iomanip>
#include "Matrix.h"

using namespace std;

bool add(Matrix& A, Matrix& B, Matrix& C);

bool skalar(double K, Matrix& A, Matrix& C);

bool multi(Matrix& A, Matrix& B, Matrix& C);

bool transponse(Matrix& A, Matrix& C);