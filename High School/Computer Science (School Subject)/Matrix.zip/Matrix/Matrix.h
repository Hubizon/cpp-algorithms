#pragma once
#include <iostream>
#include <iomanip>
#include <climits>
#include <random>

using namespace std;

class Matrix
{
protected:
    double** a;
    int m, n;
    string name;

public:
    Matrix();
    Matrix(int m_, int n_, string name_);
    Matrix(const Matrix& matrix_);
    ~Matrix();
    Matrix& operator= (const Matrix& A);
    friend Matrix operator+ (Matrix& A, Matrix& B);
    friend Matrix operator* (Matrix& A, int b);
    friend Matrix operator* (Matrix& A, Matrix& B);
    friend istream& operator>> (istream& s, Matrix& A);
    friend ostream& operator<< (ostream& s, Matrix& A);
    void create(int m_, int n_);
    void fill(int l = 30);
    void show();
    double** getA() { return a; };
    int getM() { return m; };
    int getN() { return n; };
    double get(int i, int j) { return a[i][j]; };
    string getName() { return name; };
    void setM(double m_) { m = m_; };
    void setN(double n_) { n = n_; };
    void setName(string name_) { name = name_; };
    void set(int i, int j, double r) { a[i][j] = r; };
    static double determinant(Matrix& A);
    static double det(int n, int startingRow, int* colAvailable, double** a);
};