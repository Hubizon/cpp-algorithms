#include <iostream>
#include <algorithm>
#include <ctime>
#include <chrono>
#include <iostream>
#include <fstream>

using namespace std;

ofstream out;

void insertionSort(int* arr, int size)
{
    for (int i = 1; i < size; i++) {
        int j = i;
        int temp = arr[j];
        while (j != 0 && arr[j - 1] > temp) {
            arr[j] = arr[j - 1];
            j--;
        }
        arr[j] = temp;
    }
}

void countingSort(int* arr, int size)
{
    int min = arr[0], max = arr[0];
    for (int i = size; i--;) {
        if (arr[i] < min)
            min = arr[i];
        else if (arr[i] > max)
            max = arr[i];
    }
    int countersSize = max - min + 1;
    int* counters = new int[countersSize];
    for (int i = countersSize; i--;)
        counters[i] = 0;
    for (int i = size; i--;)
        counters[arr[i] - min]++;
    for (int i = countersSize, j = size - 1; i--;) {
        for (int k = counters[i]; k--;) {
            arr[j] = min + i;
            j--;
        }
    }
    delete[] counters;
}

void merge(int*, int, int, int);

void mergeSort(int* arr, int start, int end) {
    if (end > start)
    {
        int mid = (start + end) / 2;
        mergeSort(arr, start, mid);
        mergeSort(arr, mid + 1, end);
        merge(arr, start, mid, end);
    }
}

void merge(int* arr, int start, int mid, int end)
{
    int n1 = mid - start + 1;
    int n2 = end - mid;

    int* L = new int[n1];
    int* R = new int[n2];

    for (int i = 0; i < n1; i++)
        L[i] = arr[start + i];
    for (int j = 0; j < n2; j++)
        R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = start;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j])
            arr[k++] = L[i++];
        else
            arr[k++] = R[j++];
    }

    while (i < n1)
        arr[k++] = L[i++];
    while (j < n2)
        arr[k++] = R[j++];

    delete[] L;
    delete[] R;
}

float profile(int n)
{
    float v = 0.0f;
    if (out.good()) {
        out.open("result1.txt");
        int* arr;
        for (int i = 0; i < n; i++)
        {
            int size = 50 * i;
            arr = new int[size];
            for (int i = size; i--;)
                arr[i] = (rand() % INT_MAX);
            auto start = chrono::high_resolution_clock::now();
            insertionSort(arr, size);
            //countingSort(arr, size);
            //mergeSort(arr, 0, size - 1);
            auto finish = chrono::high_resolution_clock::now();
            chrono::duration<float> elapsed = finish - start;
            delete[] arr;
            out << elapsed.count() << "\n";
            v += elapsed.count();
        }
        out.close();
        return v / (float)n;
    }

    cout << "Blad utworzenia pliku" << endl;
    return 0;
}

int main()
{
    int n;
    cin >> n;
    cout << profile(n);
}
