﻿using System;

namespace Firma
{
    public enum Plcie
    {
        K,
        M,
    }

    public class Program
    {
        public static string[] fdate = { "yyyy-MM-dd", "yyyy/MM/dd", "MM/dd/yy", "dd-MMM-yyyy", "dd-MMM-yy", "yyyy-MM-dd", "dd.MM.yyyy" };
        static void Main()
        {
            /*Osoba osoba1 = new Osoba("Beata", "Nowak", "1992-10-22", "92102201347", Plcie.K);
            Osoba osoba2 = new Osoba("Jan", "Janowski", "1993-03-15", "92031507772", Plcie.M);
            Console.WriteLine(osoba1.ToString());
            Console.WriteLine(osoba2.ToString());*/

            /*CzlonekZespolu czlonekZespolu1 = new CzlonekZespolu("Beata", "Nowak", "1992-10-22", "92102201347", Plcie.K, "projektant", "(01-sty-2020)");
            CzlonekZespolu czlonekZespolu2 = new CzlonekZespolu("Jan", "Janowski", "1992-03-15", "92031507772", Plcie.M, "programista", "(01-cze-2019)");
            KierownikZespolu kierownikZespolu = new KierownikZespolu("Adam", "Kowalski", "1990-07-01", "90070100211", Plcie.M, 5);
            Console.WriteLine(czlonekZespolu1.ToString());
            Console.WriteLine(czlonekZespolu2.ToString());
            Console.WriteLine(kierownikZespolu.ToString());*/

            Zespol zespol = PrzykladowyZespol();
            Zespol zespol2 = (Zespol)zespol.Clone();
            KierownikZespolu kierownik2 = new KierownikZespolu("Rafał", "Marzec", "01.07.1990", "88032112357", Plcie.M, 6);
            zespol2.Nazwa = "NowaGrupa";
            zespol2.Kierownik = kierownik2;

            //Console.WriteLine(zespol.ToString());
            //Console.WriteLine(zespol2.ToString());

            //zespol2.ZapiszBin("zespol");
            //Zespol zespol3 = (Zespol) zespol2.OdczytajBin("zespol");
            zespol2.ZapiszXML("zespol");
            Zespol zespol3 = Zespol.OdczytajXML("zespol");

            Console.WriteLine(zespol2.ToString());
            Console.WriteLine(zespol3.ToString());

            Console.ReadKey();
        }

        public static Zespol PrzykladowyZespol()
        {
            KierownikZespolu kierownik = new KierownikZespolu("Adam", "Kowalski", "30.06.1990", "90070142412", Plcie.M, 5);
            Zespol zespol = new Zespol("Grupa IT", kierownik);
            CzlonekZespolu czlonekZespolu1 = new CzlonekZespolu("Witold", "Adamski", "22.10.1992", "92102266738", Plcie.M, "sekretarz", "(01-sty-2020)");
            zespol.DodajCzlonka(czlonekZespolu1);
            CzlonekZespolu czlonekZespolu2 = new CzlonekZespolu("Jan", "Janowski", "15.03.1992", "92031532652", Plcie.M, "programista", "(01-sty-2020)");
            zespol.DodajCzlonka(czlonekZespolu2);
            CzlonekZespolu czlonekZespolu3 = new CzlonekZespolu("Jan", "But", "16.05.1992", "92051613915", Plcie.M, "programista", "(01-cze-2019)");
            zespol.DodajCzlonka(czlonekZespolu3);
            CzlonekZespolu czlonekZespolu4 = new CzlonekZespolu("Beata", "Nowak", "22.11.1993", "93112225023", Plcie.K, "projektant", "(01-sty-2020)");
            zespol.DodajCzlonka(czlonekZespolu4);
            CzlonekZespolu czlonekZespolu5 = new CzlonekZespolu("Anna", "Myszka", "22.07.1991", "91072235964", Plcie.K, "projektant", "(31-lip-2019)");
            zespol.DodajCzlonka(czlonekZespolu5);

            return zespol;
        }
    }
}