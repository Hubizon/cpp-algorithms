﻿using System;
using System.Globalization;

namespace Firma
{
    [Serializable]
    public class CzlonekZespolu : Osoba, ICloneable, IComparable<CzlonekZespolu>
    {
        DateTime dataZapisu; // data wstąpienia członka do zespołu
        string funkcja; // funkcja członka zespołu
        public string Funckja { get => funkcja; set => funkcja = value; }
        public DateTime DataZapisu { get => dataZapisu; set => dataZapisu = value; }

        public CzlonekZespolu() : base()
        {
            funkcja = "";
        }

        public CzlonekZespolu(string imie, string nazwisko, string funkcja, string dataZapisu) : base(imie, nazwisko)
        {
            DateTime.TryParseExact(dataZapisu, new[] { "(dd-MMM-yyyy)", "yyyy-MM-dd" }, null, DateTimeStyles.None, out this.dataZapisu);
            this.funkcja = funkcja;
        }

        public CzlonekZespolu(string imie, string nazwisko, string dataUrodzenia, string pesel, Plcie plec, string funkcja, string dataZapisu) : base(imie, nazwisko, dataUrodzenia, pesel, plec)
        {
            DateTime.TryParseExact(dataZapisu, new[] { "(dd-MMM-yyyy)", "yyyy-MM-dd" }, null, DateTimeStyles.None, out this.dataZapisu);
            this.funkcja = funkcja;
        }

        public override String ToString()
        {
            string s = base.ToString();
            //return String.Format(s + "Data zapisu: {0}\nFunckja: {1}\n", dataZapisu, funkcja);
            return String.Format("{0} {1}", s, funkcja);
        }

        public object Clone()
        {
            return MemberwiseClone();
        }

        public int CompareTo(CzlonekZespolu other)
        {
            int c = string.Compare(this.Nazwisko, other.Nazwisko);
            if (c != 0)
                return c;
            return string.Compare(this.Imie, other.Imie);
        }
    }
}
