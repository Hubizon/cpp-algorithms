﻿using System;

namespace Firma
{
    internal interface IZapisywalna
    {
        void ZapiszBin(string nazwa);
        Object OdczytajBin(string nazwa);
    }
}