﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Firma
{
    [Serializable]
    public class Zespol : ICloneable, IZapisywalna
    {
        private int liczbaCzlonkow;
        private string nazwa;
        private KierownikZespolu kierownik;
        private List<CzlonekZespolu> czlonkowie;
        public int LiczbaCzlonkow { get => liczbaCzlonkow; set => liczbaCzlonkow = value; }
        public string Nazwa { get => nazwa; set => nazwa = value; }
        public KierownikZespolu Kierownik { get => kierownik; set => kierownik = value; }
        public List<CzlonekZespolu> Czlonkowie { get => czlonkowie; set => czlonkowie = value; }

        public Zespol()
        {
            liczbaCzlonkow = 0;
            Nazwa = null;
            Kierownik = null;
            czlonkowie = new List<CzlonekZespolu>();
        }

        public Zespol(string nazwa, KierownikZespolu kierownik)
        {
            liczbaCzlonkow = 0;
            this.Nazwa = nazwa;
            this.Kierownik = kierownik;
            czlonkowie = new List<CzlonekZespolu>();
        }

        public void DodajCzlonka(CzlonekZespolu c)
        {
            czlonkowie.Add(c);
        }

        public new string ToString()
        {
            string s = String.Format("Nazwa zespołu: {0}\nKierownik: \n{1}\nCzlonkowie:\n", nazwa, kierownik.ToString());
            foreach (CzlonekZespolu czlonek in czlonkowie)
                s += czlonek.ToString() + '\n';
            return s;
        }
        public bool JestCzlonkiem(string PESEL)
        {
            foreach (CzlonekZespolu czlonek in czlonkowie)
                if (czlonek.Pesel == PESEL)
                    return true;
            return false;
        }

        public bool JestCzlonkiem(string imie, string nazwisko)
        {
            foreach (CzlonekZespolu czlonek in czlonkowie)
                if (czlonek.Imie == imie && czlonek.Nazwisko == nazwisko)
                    return true;
            return false;
        }

        public void UsunCzlonka(string PESEL)
        {
            for (int i = 0; i < liczbaCzlonkow; i++)
            {
                if (czlonkowie[i].Pesel == PESEL)
                {
                    czlonkowie.RemoveAt(i);
                    liczbaCzlonkow--;
                    return;
                }
            }
        }

        public void UsunCzlonka(string imie, string nazwisko)
        {
            for (int i = 0; i < liczbaCzlonkow; i++)
            {
                if (czlonkowie[i].Imie == imie && czlonkowie[i].Nazwisko == nazwisko)
                {
                    czlonkowie.RemoveAt(i);
                    liczbaCzlonkow--;
                    return;
                }
            }
        }

        public void UsunWszystkich()
        {
            czlonkowie.Clear();
            liczbaCzlonkow = 0;
        }

        public List<CzlonekZespolu> WyszukajCzlonkow(string funkcja)
        {
            return czlonkowie.FindAll(czlonek => czlonek.Funckja == funkcja);
        }

        public List<CzlonekZespolu> WyszukajCzlonkow(int miesiac)
        {
            return czlonkowie.FindAll(czlonek => czlonek.DataZapisu.Month == miesiac);
        }

        public void Sortuj()
        {
            czlonkowie.Sort();
        }

        public class PESELComperator : IComparer<CzlonekZespolu>
        {
            public int Compare(CzlonekZespolu x, CzlonekZespolu y)
            {
                return string.Compare(x.Pesel, y.Pesel);
            }
        }

        public bool JestCzlonkiem(CzlonekZespolu czlonekZespolu)
        {
            foreach (CzlonekZespolu czlonek in czlonkowie)
                if (czlonekZespolu.Equals(czlonek))
                    return true;
            return false;
        }

        public void SortujPoPESEL()
        {
            czlonkowie.Sort(new PESELComperator());
        }

        public object Clone()
        {
            return MemberwiseClone();
        }

        public void ZapiszBin(string nazwa)
        {
            Hashtable addresses = new Hashtable
            {
                { "LiczbaCzlonkow", liczbaCzlonkow },
                { "Nazwa", this.nazwa },
                { "Czlonkowie", czlonkowie },
                { "Kierownik", kierownik }
            };

            FileStream fs = new FileStream(String.Format("{0}.bin", nazwa), FileMode.Create);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fs, addresses);
            fs.Close();
        }

        public object OdczytajBin(string nazwa)
        {
            FileStream fs = new FileStream(String.Format("{0}.bin", nazwa), FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            Hashtable addresses = (Hashtable)formatter.Deserialize(fs);
            fs.Close();

            Zespol zespol = new Zespol((string)addresses["Nazwa"], (KierownikZespolu)addresses["Kierownik"])
            {
                LiczbaCzlonkow = (int)addresses["LiczbaCzlonkow"],
                czlonkowie = (List<CzlonekZespolu>)addresses["Czlonkowie"]
            };

            return zespol;
        }

        public void ZapiszXML(string nazwa)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Zespol));
            TextWriter writer = new StreamWriter(nazwa);
            serializer.Serialize(writer, this);
            writer.Close();
        }

        public static Zespol OdczytajXML(string nazwa)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Zespol));
            FileStream fs = new FileStream(nazwa, FileMode.Open);
            return (Zespol)serializer.Deserialize(fs);
        }
    }
}