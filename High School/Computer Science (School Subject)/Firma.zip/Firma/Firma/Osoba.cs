﻿using System;
using System.Globalization;

namespace Firma
{
    [Serializable]
    public abstract class Osoba : IEquatable<Osoba>
    {
        protected string imie;
        public string Nazwisko { get; set; }
        protected DateTime dataUrodzenia;
        protected string pesel;
        protected Plcie plec;
        public string Imie { get => imie; set => imie = value; }
        public DateTime DataUrodzenia { get => dataUrodzenia; set => dataUrodzenia = value; }
        public string Pesel { get => pesel; set => pesel = value; }
        public Plcie Plec { get => plec; set => plec = value; }

        public Osoba()
        {
            imie = "";
            Nazwisko = "";
            pesel = new string('0', 11);
        }

        public Osoba(string imie, string nazwisko)
        {
            this.imie = imie;
            this.Nazwisko = nazwisko;
        }

        public Osoba(string imie, string nazwisko, string dataUrodzenia, string pesel, Plcie plec)
        {
            this.imie = imie;
            this.Nazwisko = nazwisko;
            DateTime.TryParseExact(dataUrodzenia, Program.fdate, null, DateTimeStyles.None, out this.dataUrodzenia);
            this.pesel = pesel;
            this.plec = plec;
        }

        public int Wiek()
        {
            int years = DateTime.Now.Year - dataUrodzenia.Year;
            years -= Convert.ToInt32(dataUrodzenia.AddYears(years) > DateTime.Now);
            return years;
        }

        /*public new void ToString()
        {
            Console.WriteLine("Imię: {0}\nNazwisko: {1}\nPESEL: {2}", imie, Nazwisko, PESEL);
        }*/
        public override String ToString()
        {
            //return String.Format("Imię: {0}\nNazwisko: {1} ({2} lat)\nPESEL: {3}\n", imie, Nazwisko, Wiek(), pesel);
            return String.Format("{0} {1}, {2} {3}", imie, Nazwisko, pesel, dataUrodzenia.ToString("dd-MM-yyyy"));
        }

        public bool Equals(Osoba other)
        {
            return (this.Pesel == other.Pesel);
        }
    }
}