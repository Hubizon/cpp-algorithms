﻿using System;

namespace Firma
{
    [Serializable]
    public class KierownikZespolu : Osoba, ICloneable
    {
        private int doswiadczenie; // liczba lat przepracowanych przez osobę na stanowisku kierownika
        public int Doswiadczenie { get => doswiadczenie; set => doswiadczenie = value; } // liczba lat przepracowanych przez osobę na stanowisku kierownika

        public KierownikZespolu() : base()
        {
            doswiadczenie = 0;
        }

        public KierownikZespolu(string imie, string nazwisko, int doswiadczenie) : base(imie, nazwisko)
        {
            this.doswiadczenie = doswiadczenie;
        }

        public KierownikZespolu(string imie, string nazwisko, string dataUrodzenia, string pesel, Plcie plec, int doswiadczenie) : base(imie, nazwisko, dataUrodzenia, pesel, plec)
        {
            this.doswiadczenie = doswiadczenie;
        }

        public object Clone()
        {
            return MemberwiseClone();
        }

        /*public new String ToString()
        {
            string s = base.ToString();
            return String.Format(s + "Doswiadczenie: {0}\n", doswiadczenie);
        }*/
    }
}
