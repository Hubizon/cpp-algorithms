﻿using Firma;
using System;
using System.Globalization;
using System.Windows;

namespace ZespolGUI
{
    public partial class OsobaWindow : Window
    {
        readonly Osoba osoba;
        public OsobaWindow(Osoba osoba)
        {
            InitializeComponent();
            this.osoba = osoba;
            txtPesel.Text = osoba.Pesel;
            txtImie.Text = osoba.Imie;
            txtNazwisko.Text = osoba.Nazwisko;
            txtDataUrodz.Text = osoba.DataUrodzenia.ToString("dd-MMM-yyyy");
            cmbPlec.SelectedIndex = (osoba.Plec == Plcie.M) ? 0 : 1;
            lblAdditional.Content = (osoba is KierownikZespolu) ? "Doświadczenie" : "Funkcja";
            txtAdditional.Text = (osoba is KierownikZespolu kierownik) ? kierownik.Doswiadczenie.ToString() : ((CzlonekZespolu)osoba).Funckja;
        }

        private void BtnZatwierdz_Click(object sender, RoutedEventArgs e)
        {
            if (!DateTime.TryParseExact(txtDataUrodz.Text, Program.fdate, null, DateTimeStyles.None, out DateTime date))
                MessageBox.Show("Wrong date format!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (txtAdditional.Text != "" && txtPesel.Text != "" && txtImie.Text != "" && txtNazwisko.Text != "")
            {
                osoba.Pesel = txtPesel.Text;
                osoba.Imie = txtImie.Text;
                osoba.Nazwisko = txtNazwisko.Text;
                osoba.DataUrodzenia = date;
                osoba.Plec = (cmbPlec.SelectedIndex == 0) ? Plcie.M : Plcie.K;
                if (osoba is KierownikZespolu kiewonik)
                    kiewonik.Doswiadczenie = Int32.Parse(txtAdditional.Text);
                else
                    ((CzlonekZespolu)osoba).Funckja = txtAdditional.Text;
                DialogResult = true;
            }
            else
                MessageBox.Show("Fill in the data.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void BtnAnuluj_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
