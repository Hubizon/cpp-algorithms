﻿using Firma;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
 
namespace ZespolGUI
{
    public partial class MainWindow : Window
    {
        ObservableCollection<CzlonekZespolu> list;
        Zespol zespol;
        bool isChanged;

        public MainWindow()
        {
            InitializeComponent();
            OpenFile("zespol.xml");
            isChanged = false;
        }

        private void BtnZmien_Click(object sender, RoutedEventArgs e)
        {
            OsobaWindow okno = new(zespol.Kierownik);
            okno.ShowDialog();
            txtKierownik.Text = zespol.Kierownik.ToString();
            isChanged = true;
        }

        private void BtnDodaj_Click(object sender, RoutedEventArgs e)
        {
            CzlonekZespolu cz = new();
            OsobaWindow okno = new(cz);
            okno.ShowDialog();
            if (cz.Imie != "")
            {
                zespol.DodajCzlonka(cz);
                list.Add(cz);
                isChanged = true;
            }
        }

        private void BtnUsun_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = lstCzlonkowie.SelectedIndex;
            if (zaznaczony != -1)
            {
                list.RemoveAt(zaznaczony);
                zespol.Czlonkowie.RemoveAt(zaznaczony);
                isChanged = true;
            }
        }

        private void MenuZapisz_Click(object sender, RoutedEventArgs e)
        {
            SaveFile();
            isChanged = false;
        }

        private void MenuOtworz_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new()
            { Filter = "XML file (*.xml)|*.xml" };
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string filename = dlg.FileName;
                OpenFile(filename);
            }
        }

        private void MenuWyjdz_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void OpenFile(string fileName)
        {
            if (!File.Exists(fileName))
                Program.PrzykladowyZespol().ZapiszXML(fileName);
            zespol = Zespol.OdczytajXML(fileName);
            list = new ObservableCollection<CzlonekZespolu>(zespol.Czlonkowie);
            lstCzlonkowie.ItemsSource = list;
            txtNazwa.Text = zespol.Nazwa;
            txtKierownik.Text = zespol.Kierownik.ToString();
            isChanged = false;
        }

        private void SaveFile()
        {
            Microsoft.Win32.SaveFileDialog dlg = new()
            { Filter = "XML file (*.xml)|*.xml" };
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string filename = dlg.FileName;
                zespol.Nazwa = txtNazwa.Text;
                zespol.ZapiszXML(filename);
            }
        }

        override protected void OnClosed(EventArgs e)
        {
            if (isChanged)
            {
                MessageBoxResult result = MessageBox.Show("You have some unsaved changes. Do you want to save them before closing?",
                                          "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                    SaveFile();
            }
        }

        private void TxtNazwa_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (zespol != null)
                zespol.Nazwa = ((TextBox)sender).Text;
            isChanged = true;
        }

        private void BtnZmienCzlonka_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = lstCzlonkowie.SelectedIndex;
            if (zaznaczony != -1)
            {
                OsobaWindow okno = new(zespol.Czlonkowie[zaznaczony]);
                okno.ShowDialog();
                txtKierownik.Text = zespol.Kierownik.ToString();
                list = new ObservableCollection<CzlonekZespolu>(zespol.Czlonkowie);
                lstCzlonkowie.ItemsSource = list;
                isChanged = true;
            }
        }
    }
}
