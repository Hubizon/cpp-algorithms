#include <iostream>
#include <algorithm>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

const int AlpS = 'z' - 'a' + 1;

string mySort(string S) {
	vector<int> V(CHAR_MAX);
	for (int i = 0; i < S.size(); i++)
		V[S[i]]++;

	string R;
	for (int i = 0; i < CHAR_MAX; i++)
		for (int j = 0; j < V[i]; j++)
			R.push_back(i);
	return R;
}

bool check2(string A, string B) {
	A = mySort(A);
	B = mySort(B);
	return A == B;
}

bool check(string A, string B) {
	sort(A.begin(), A.end());
	sort(B.begin(), B.end());
	return A == B;
}

int main()
{
	ifstream in("anagramy.txt");
	ofstream out("wyniki3.txt");

	vector<string> V;
	string line;
	while (getline(in, line))
		V.push_back(line);

	string res2 = "";
	int res3 = 0;
	vector<string> R3;

	int n = V.size();
	for (int i = 0; i < n; i++) {
		vector<string> T3 = { V[i] };
		for (int j = 0; j < n; j++) {
			if (i == j) continue;
			if (check(V[i], V[j]))
				T3.push_back(V[j]);
		}
		int Acnt = T3.size();

		// zad 2
		if (Acnt == 1)
			res2 = V[i];

		// zad 3
		if (Acnt > res3) {
			res3 = Acnt;
			R3 = T3;
		}
	}

	out << "Zadanie 3.2.: " << res2;

	out << "\n\nZadanie 3.3.: " << res3 << '\n';
	for (auto& r3 : R3)
		out << r3 << ' ';
}
