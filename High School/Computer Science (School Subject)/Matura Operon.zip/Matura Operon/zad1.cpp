#include <iostream>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

constexpr int MAX_IN = 1e3; // ???

int main()
{
	ifstream in("przedzialy.txt");
	ofstream out("wyniki1.txt");

	// zad 1 preprocessing
	int res1 = 0;
	vector<int> R1;

	// zad 2 preprocessing
	vector<bool> IP(MAX_IN, true);
	IP[0] = IP[1] = false;
	for (int i = 2; i < MAX_IN; i++) {
		if (!IP[i]) continue;
		for (int j = i + i; j < MAX_IN; j += i)
			IP[j] = false;
	}

	vector<int> PPref(MAX_IN);
	for (int i = 1; i < MAX_IN; i++)
		PPref[i] = PPref[i - 1] + IP[i];

	int res2 = 0;
	vector<string> R2;

	// zad 3 preprocessing
	vector<int> S3(2 * MAX_IN);


	string line;
	int pos = 1;
	while (getline(in, line)) {
		// przetwarzanie wej�cia
		bool lO = (line.front() == '(');
		bool rO = (line.back() == ')');
		int cPos = line.find(',');
		int a = stoi(line.substr(1, cPos));
		int b = stoi(line.substr(cPos + 1, line.size() - 1));
		a += lO, b -= rO; // <a, b>

		// zad 1.1
		int tr1 = 0, ta = a, tb = b;
		if (ta < tb && ta % 2 != 0)
			ta++, tr1++;
		if (ta < tb && tb % 2 != 0)
			tb--, tr1++;
		tr1 += (tb - ta) / 2;
		if (tr1 > res1) {
			res1 = tr1;
			R1 = { pos };
		}
		else if (tr1 == res1)
			R1.push_back(pos);

		// zad 1.2
		int tr2 = PPref[max(0, b)] - PPref[max(0, a - 1)];
		if (tr2 > res2) {
			res2 = tr2;
			R2 = { line };
		}
		else if (tr2 == res2)
			R2.push_back(line);

		// zad 1.3
		a *= 2, b *= 2;
		a -= lO, b += rO;
		S3[a + MAX_IN]++;
		S3[b + MAX_IN]--;

		pos++;
	}


	// zad 3
	partial_sum(S3.begin(), S3.end(), S3.begin());
	int res3 = 0, temp3 = 0, res3a = -1, res3b = -1, tempA = 0;
	for (int i = 0; i < S3.size(); i++) {
		if (S3[i]) {
			if (!temp3)
				tempA = i - MAX_IN;
			temp3++;
		}
		else if (temp3) {
			if (res3 < temp3) {
				res3 = temp3;
				res3a = tempA;
				res3b = i - MAX_IN;
			}
			temp3 = 0;
		}
	}
	string res3s = "";
	res3s += (res3a % 2 == 0 ? "<" : "(");
	res3s += to_string((res3a + (res3a < 0 ? -1 : 1)) / 2);
	res3s += ", ";
	res3s += to_string((res3b + (res3b < 0 ? -1 : 1)) / 2);
	res3s += (res3b % 2 == 0 ? ">" : ")");

	out << "Zadanie 1.1.:\n" << res1 << ": ";
	for (auto& r1 : R1)
		out << r1 << ' ';

	out << "\n\nZadanie 1.2.:\n" << res2 << ": ";
	for (auto& r2 : R2)
		out << r2 << ' ';

	out << "\n\nZadanie 1.3.:\n" << res3s;

	in.close();
	out.close();
}
