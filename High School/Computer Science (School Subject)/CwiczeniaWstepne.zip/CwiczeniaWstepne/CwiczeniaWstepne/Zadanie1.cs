﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CwiczeniaWstepne
{
    class Zadanie1
    {
        public static void Execute1()
        {
            Console.Write("Zadanie 1: Podaj liczbę a i b (w osobnych linijkach): ");
            decimal a = decimal.Parse(Console.ReadLine());
            float b = float.Parse(Console.ReadLine());
            Console.WriteLine("a + b = {0}", Math.Round(a + (decimal)b, 2));
            Console.WriteLine("a - b = {0}", Math.Round(a - (decimal)b, 2));
            Console.WriteLine("a * b = {0}", Math.Round(a * (decimal)b, 2));
            Console.WriteLine("a / b = {0}", Math.Round(a / (decimal)b, 2));
            Console.WriteLine();
        }

        public static void Execute2()
        {
            Console.Write("Zadanie 1*: Podaj 10 liczb całkowiych (w osobnych linijkach): ");
            long sum = 0, cnt = 0;
            for (int i = 0; i < 10; i++) {
                int x = int.Parse(Console.ReadLine());
                if (x % 3 == 0 || x % 5 == 0) {
                    sum += x; 
                    cnt++;
                }
            }
            Console.WriteLine("suma liczb podzielnych przez 3 i 5: {0}", sum);
            Console.WriteLine("srednia arytmetyczna liczb podzielnych przez 3 i 5: {0}", Math.Round(1m * sum / cnt, 2));
            Console.WriteLine();
        }
    }
}
