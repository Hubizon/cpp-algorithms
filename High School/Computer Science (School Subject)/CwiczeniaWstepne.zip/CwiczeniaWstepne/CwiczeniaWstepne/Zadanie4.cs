﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CwiczeniaWstepne
{
    class Zadanie4
    {
        public static void Execute()
        {
            Console.Write("Zadanie 4: Wpisz liczbę nieujemną: ");
            uint x = uint.Parse(Console.ReadLine());
            while (x > 9)
            {
                uint temp = x;
                x = 0;
                do x += temp % 10; while ((temp /= 10) != 0);
            }
            Console.WriteLine("Pierwiastek cyfyrowy to: {0}", x);
            Console.WriteLine();
        }
    }
}
