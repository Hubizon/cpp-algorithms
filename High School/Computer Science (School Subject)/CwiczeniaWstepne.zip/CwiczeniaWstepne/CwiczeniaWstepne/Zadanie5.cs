﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CwiczeniaWstepne
{
    class Zadanie5
    {
        public static void Execute()
        {
            Console.Write("Zadanie 5: Wpisz tekst: ");
            string s = Console.ReadLine(), res = "";
            int n = s.Length, cnt = 0;
            for (int i = 0; i < n; i++)
            {
                ++cnt;
                if (i + 1 == n || s[i] != s[i + 1]) {
                    res += s[i] + cnt.ToString();
                    cnt = 0;
                };
            }
            Console.WriteLine("\'Skompresowany\' tekst to: " + res);
            Console.WriteLine();
        }
    }
}
