﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CwiczeniaWstepne
{
    class Zadanie3
    {
        public static void Execute()
        {
            Console.Write("Zadanie 3: Wpisz tekst ([tekst1][znak][tekst2]): ");
            string x = Console.ReadLine();
            int cnt = 0, pos = 0, size = x.Length;
            for (int i = 0; i < size; i++)
            {
                if (x[i] < 'a' || x[i] > 'z') {
                    pos = i;
                    cnt++;
                }
            }

            if (cnt != 1 || pos == 0 || pos == size) {
                Console.WriteLine("Błędne dane.");
                return;
            }

            Console.WriteLine("Wynik to: {0}{1}{2}", x.Substring(pos + 1), 
                x[pos], x.Substring(0, pos));
            Console.WriteLine();
        }
    }
}
