﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CwiczeniaWstepne
{
    class Zadanie2
    {
        public static void Execute1()
        {
            Console.Write("Zadanie 2: Podaj liczbę całkowitą dodatnią: ");
            uint x = uint.Parse(Console.ReadLine());
            while (x > 0)
            {
                if (x % 10 == 3) {
                    Console.Write("W tej liczbie występuje cyfra 3.");
                    return;
                }
                x /= 10;
            }
            Console.WriteLine("W tej liczbie nie występuje cyfra 3.");
        }

        public static void Execute2()
        {
            Console.Write("Zadanie 2*: Podaj liczbę całkowitą dodatnią: ");
            string x = Console.ReadLine();
            if (x.Contains('3')) Console.Write("W tej liczbie występuje cyfra 3.");
            else Console.WriteLine("W tej liczbie nie występuje cyfra 3.");
        }
    }
}
