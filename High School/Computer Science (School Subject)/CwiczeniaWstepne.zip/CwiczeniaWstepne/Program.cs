﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CwiczeniaWstepne
{
    class Program
    {
        static void Main(string[] args)
        {
            //Zadanie1.Execute1();
            //Zadanie1.Execute2();
            //Zadanie2.Execute1();
            //Zadanie2.Execute2();
            Zadanie3.Execute();
            Console.ReadKey(); 
        }
    }
}
